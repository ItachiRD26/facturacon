<?php
require_once 'keys.inc.php';
require_once 'lib/class.pagadito.php';

$params = array(
    'card' => array(
        'number'         => '5555555555554444',
        'expirationDate' => '12/2030',
        'cvv'            => '123',
        'cardHolderName' => 'JONH DOE',
        'firstName'      => 'John',
        'lastName'       => 'Doe',
        'billingAddress' => array(
            'city'       => 'Los Angeles',
            'state'      => 'CA',
            'zip'        => '90011',
            'countryId'  => '840',
            'line1'      => 'Street 1',
            'phone'      => '+1 213 7777777',
        ),
        'email'          => 'youremail@domain.com',
    ),
    'recurring' => array(
        'interval'              => 'month',
        'interval_count'        => '3',
        'first_interval_free'   => false,
        'merchantTransactionId' => 'SUB-' . rand(),
        'description'           => 'Service info or product data',
        'interval_amount'       => '10.00'
    ),
    'browserInfo' => array(
        'deviceFingerprintID'   => '1234567890123456',
        'customerIp'            => '172.217.8.78',
    ),
);

/* Now, you send information to Pagadito */
$pagadito = new Pagadito(false); //Change true to debug
$res = $pagadito->createSubscription($params);

/* You may store the information received */
print_r($res);
echo "\n";
