<?php
/* Copy from Technical Configuration -> Integration Parameters */
define("KEY_UID", "CHANGE_ME");
define("KEY_WSK", "CHANGE_ME");

/* If your project is live, uncomment the following line, and comment the next one */
// define("GATEWAY_URL", "https://api.pagadito.com/v1/");
define("GATEWAY_URL", "https://sandbox-api.pagadito.com/v1/");
