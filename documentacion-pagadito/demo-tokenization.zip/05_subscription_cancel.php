<?php
require_once 'keys.inc.php';
require_once 'lib/class.pagadito.php';

$params = array(
    'subscription_code' => 'sub_21picl7ja4',
);

$pagadito = new Pagadito(false); //Change true to debug
$res = $pagadito->cancelSubscription($params);

print_r($res);
echo "\n";
