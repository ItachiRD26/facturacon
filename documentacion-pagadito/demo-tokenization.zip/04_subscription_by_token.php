<?php
require_once 'keys.inc.php';
require_once 'lib/class.pagadito.php';

$params = array(
    'payment_token' => 'cus_f1128bbf9aeb946e', //Token for the first script
    'recurring' => array(
        'interval'              => 'month',
        'interval_count'        => '3',
        'first_interval_free'   => false,
        'merchantTransactionId' => 'SUBS-' . rand(),
        'description'           => 'Service info or product data',
        'interval_amount'       => '10.00'
    ),
    'browserInfo' => array(
        'deviceFingerprintID'   => '1234567890123456',
        'customerIp'            => '172.217.8.78',
    ),
);

$pagadito = new Pagadito(false); //Change true to debug
$res = $pagadito->sendSubscriptionToken($params);

print_r($res);
echo "\n";
