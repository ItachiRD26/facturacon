<?php
require_once 'keys.inc.php';
require_once 'lib/class.pagadito.php';

$params = array(
    'card' => array(
        'number'         => '5555555555554444',
        'expirationDate' => '12/2030',
        'cvv'            => '123',
        'cardHolderName' => 'JONH DOE',
        'firstName'      => 'John',
        'lastName'       => 'Doe',
        'billingAddress' => array(
            'city'       => 'Los Angeles',
            'state'      => 'CA',
            'zip'        => '90011',
            'countryId'  => '840',
            'line1'      => 'Street 1',
            'phone'      => '+1 213 7777777',
        ),
        'email'          => 'youremail@domain.com',
    ),
    'transaction' => array(
        'merchantTransactionId' => 'TRS-' . rand(),
        'currencyId'            => 'USD',
        'transactionDetails' => array(
            array(
                'quantity'      => '2',
                'description'   => 'Service info or product description',
                'amount'        => '10.00',
            )
        ),
    ),
    'browserInfo' => array(
        'deviceFingerprintID'   => '1234567890123456',
        'customerIp'            => '172.217.8.78',
    ),
);

$pagadito = new Pagadito(false); //Change true to debug
$res = $pagadito->createCustomer($params);

print_r($res);
echo "\n";
