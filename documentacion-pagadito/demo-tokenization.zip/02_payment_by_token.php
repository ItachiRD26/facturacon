<?php
require_once 'keys.inc.php';
require_once 'lib/class.pagadito.php';

$params = array(
    'payment_token' => 'cus_dd3c1dcb310f2648', //Token for the first script
    'transaction' => array(
        'merchantTransactionId' => 'TRS-' . rand(),
        'currencyId'            => 'USD',
        'transactionDetails' => array(
            array(
                'quantity'      => '2',
                'description'   => 'Service info or product description',
                'amount'        => '25.00',
            )
        ),
    ),
    'browserInfo' => array(
        'deviceFingerprintID'   => '1234567890123456',
        'customerIp'            => '172.217.8.78',
    ),
);

$pagadito = new Pagadito(false); //Change true to debug
$res = $pagadito->sendPayment($params);

echo "\n\n";
print_r($res);
echo "\n\n";
