import React from 'react';
import {  SafeAreaView, View,  Text, Button, NativeModules } from 'react-native';
import PagaditoLibrary from './PagaditoLibrary';

import { useState } from 'react';
import { encode } from 'base-64';

export default function App() {

     var productionUrl = "https://api.pagadito.com/v1/customer";
     var stagingUrl = "https://sandbox-api.pagadito.com/v1/customer";
     var UID = ""; // merchant UID
     var WSK = ""; // merchant WSK

     
       
     const [sessionID, setSessionID] = useState('');
     const [requestID, setRequestID] = useState('');

    console.log(PagaditoLibrary);
    //console.log(sessionID);

      function createSampleBody() {
         var paymentItem = {  
              card: {},
              transaction: {},
              browserInfo: {}
         };
         paymentItem.card = {
             "number": "5555555555554444",
             "expirationDate": "01/2024",
             "cvv": "123",
             "cardHolderName": "JOHN SMITH",
             "firstName": "John",
             "lastName": "Smith",
             "billingAddress": {},
             "email": "johnsmith@correo.com"
         };
         paymentItem.card.billingAddress = {
             "city": "San Salvador",
             "state": "San Salvador",
             "zip": "",
             "countryId": "222", /// 222 es El Salvador
             "line1": "7a calle poniente bis",
             "phone": "+503 7695 4199"
         };
         paymentItem.transaction = {
             "merchantTransactionId": "Inv 001-002",
             "currencyId": "USD",
            "transactionDetails": []
         };
         paymentItem.transaction.transactionDetails.push({
             "quantity": "1",
             "description": "Teclado Generico",
             "amount": "20.00"
         });
         paymentItem.browserInfo = {
             "deviceFingerprintID": sessionID,
             "customerIp": "190.120.8.26"
         };
        return paymentItem;
 }
 async function payToPagadito() {
     try {
             fetch(stagingUrl, {
                 method: 'POST',
                 headers: {
                 'Content-Type': 'application/json',
                 'Authorization': 'Basic ' + encode(UID + ":" + WSK)
             },
             body: JSON.stringify(createSampleBody())
             })
             .then(response => response.json())
             .then(data => {
              console.log('Success:', JSON.stringify(data));
              setRequestID(JSON.stringify(data));
             })
             .catch((error) => {
             console.error('Error:', error);
             });
         } catch (error) {
            console.error('Error:', error);
         }
 }
 async function requestFingerprint() {
     try {
         // false for SANDBOX environment, true for PRODUCTION environment
         var resultSession = await PagaditoLibrary.requestFingerprint(true);
         console.log( "resultSession" );
         console.log( resultSession );
         setSessionID(resultSession);
     } catch (e) {
        console.error(e);
     }
 }

 return (
 <>
     <SafeAreaView>
        <View>
             <Button
             onPress={() => {PagaditoLibrary.setTimeout(60);}}
             title="set timeout" />
             <Button
                 onPress={() => {
                 requestFingerprint();
                 }} title="request fingerprint" />
             <Text>{sessionID}</Text>
             <Button onPress={ () => {
                payToPagadito();
                }} title="do request" />
              <Text>{requestID}</Text>
             
        </View>
     </SafeAreaView>
 </>
 );
};
 