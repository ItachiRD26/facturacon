import { NativeModules } from 'react-native';

const { PagaditoLibrary } = NativeModules;

export default PagaditoLibrary;