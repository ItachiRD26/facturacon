package com.awesomeproject;

import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import java.util.Map;
import java.util.HashMap;
import android.util.Log;

import com.devicefingerprint.pagaditofingerprint.DeviceFingerprint;

public class PagaditoLibrary extends ReactContextBaseJavaModule {
    private static ReactApplicationContext reactContext;

    PagaditoLibrary(ReactApplicationContext context) {
        super(context);
        reactContext = context;
    }
    @Override
    public String getName() {
        return "PagaditoLibrary";
    }
    @ReactMethod
    public void requestFingerprint(Boolean isProduction, Promise promise) {
        //Log.d("PagaditoLibrary", "requestFingerprint" );
        DeviceFingerprint fingerprint = new DeviceFingerprint(reactContext, isProduction);
        try {
            String sessionID = fingerprint.generateSessionID();
            promise.resolve(sessionID);
        }catch(Exception e){
            promise.reject(e);
        }
    }
}

